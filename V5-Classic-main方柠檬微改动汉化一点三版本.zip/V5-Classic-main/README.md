![Logo](sprites-override/logo.png)

Testing: Passed in V7 :)

Description:

Adds v5 units into the recent version of Mindustry: v137! 
BTW, this mod was made through my Android Mobile,
I recommended the pre-alpha since the sounds are not avaliable in v137 so some of them are muted.
This mod is using the v104.6 (v5) version of the Mindustry to able to make this mod,
and maybe become a v5 user again by this mod.

---
Status:
#### Release Current Version of the mod: v1.022 Beta (V7 support)
#### Pre-Release Current Version of the mod: v1.07 Beta (Snek moment)
---
Game Version:
#### Recommended Game Version: v139 (beta)
#### Minimum Game Version: v126 (stable)
---
Creators:

VvSeanGtvV#2295 - Full on revamp Coding to fit in v126 Mindustry

---
⚠️ WARNING Before using the mod! ⚠️

All of the units/blocks doesnt have the abilities yet like: Javelin-Shield and Omega's Damage Resistance!
Anyways bye!

Some v5 Sounds are not imported yet to this mod!

This mod is not gonna be updated anymore! go to the new mod i hav released!

---
Check out the links:

[Official Mindustry Discord](https://discord.gg/aDWth4RCb3)

[New v5 Mod](https://github.com/VvSeanGTvV/V5-Reborn-Java)

[My YouTube Channel](https://youtube.com/channel/UC-TtlQ6ARi4OmqUYsNVvjjg)
